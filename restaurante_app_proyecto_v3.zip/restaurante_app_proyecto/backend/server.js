const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const DATA_FILE = path.join(__dirname, 'reservas.json');

const initialReservations = [
  {
    id: "RES-101",
    nombreCliente: "Gerson Soriano",
    telefono: "987654321",
    email: "gerson@example.com",
    fecha: new Date().toISOString().split('T')[0],
    hora: "19:00",
    personas: 4,
    mesa: "Mesa 3 (Interior - Principal)",
    zona: "Interior",
    estado: "Confirmada",
    notas: "Cumpleaños, mesa cerca a la ventana",
    creadoEn: new Date().toISOString()
  }
];

const readData = () => {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      fs.writeFileSync(DATA_FILE, JSON.stringify(initialReservations, null, 2));
      return initialReservations;
    }
    const data = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return initialReservations;
  }
};

const writeData = (data) => {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (error) {}
};

app.get('/api/reservas', (req, res) => {
  const reservas = readData();
  res.json({ success: true, count: reservas.length, data: reservas });
});

app.post('/api/reservas', (req, res) => {
  const { nombreCliente, telefono, fecha, hora, personas, mesa, zona, notas } = req.body;
  if (!nombreCliente || !telefono || !fecha || !hora || !mesa) {
    return res.status(400).json({ success: false, message: "Campos obligatorios faltantes" });
  }

  const reservas = readData();
  const conflicto = reservas.find(r => r.fecha === fecha && r.hora === hora && r.mesa === mesa && r.estado !== 'Cancelada');

  if (conflicto) {
    return res.status(409).json({
      success: false,
      message: `¡Conflicto de Horario! La ${mesa} ya se encuentra reservada para la fecha ${fecha} a las ${hora}.`
    });
  }

  const newRes = {
    id: `RES-${Date.now().toString().slice(-4)}`,
    nombreCliente,
    telefono,
    fecha,
    hora,
    personas: parseInt(personas) || 2,
    mesa,
    zona: zona || 'Interior',
    estado: 'Confirmada',
    notas: notas || '',
    creadoEn: new Date().toISOString()
  };

  reservas.push(newRes);
  writeData(reservas);

  res.status(201).json({ success: true, data: newRes });
});

app.listen(PORT, () => {
  console.log(`Servidor Backend de Gestión de Reservas corriendo en puerto ${PORT}`);
});
