import React, { useState, useEffect } from 'react';

const initialData = [
  {
    id: "RES-101",
    nombreCliente: "Gerson Soriano",
    telefono: "987654321",
    email: "gerson@example.com",
    fecha: new Date().toISOString().split('T')[0],
    hora: "19:00",
    personas: 4,
    mesa: "Mesa 3 (Interior - Principal)",
    zona: "Interior",
    estado: "Confirmada",
    notas: "Cumpleaños, mesa cerca a la ventana",
    creadoEn: "2026-10-26T18:00:00.000Z"
  },
  {
    id: "RES-102",
    nombreCliente: "Ana Martínez",
    telefono: "912345678",
    email: "ana.m@example.com",
    fecha: new Date().toISOString().split('T')[0],
    hora: "20:30",
    personas: 2,
    mesa: "Mesa 8 (Terraza Vista Jardín)",
    zona: "Terraza",
    estado: "Confirmada",
    notas: "Cena romántica",
    creadoEn: "2026-10-26T18:15:00.000Z"
  },
  {
    id: "RES-103",
    nombreCliente: "Carlos Mendoza",
    telefono: "955443322",
    email: "carlos.m@example.com",
    fecha: new Date().toISOString().split('T')[0],
    hora: "13:30",
    personas: 6,
    mesa: "Mesa 12 (Zona VIP)",
    zona: "VIP",
    estado: "Completada",
    notas: "Almuerzo corporativo",
    creadoEn: "2026-10-26T12:00:00.000Z"
  }
];

const MESAS_DISPONIBLES = [
  { id: "Mesa 1", nombre: "Mesa 1 (Interior)", capacidad: 2, zona: "Interior" },
  { id: "Mesa 2", nombre: "Mesa 2 (Interior)", capacidad: 2, zona: "Interior" },
  { id: "Mesa 3", nombre: "Mesa 3 (Interior - Principal)", capacidad: 4, zona: "Interior" },
  { id: "Mesa 4", nombre: "Mesa 4 (Interior)", capacidad: 6, zona: "Interior" },
  { id: "Mesa 7", nombre: "Mesa 7 (Terraza Vista Jardín)", capacidad: 2, zona: "Terraza" },
  { id: "Mesa 8", nombre: "Mesa 8 (Terraza Vista Jardín)", capacidad: 4, zona: "Terraza" },
  { id: "Mesa 9", nombre: "Mesa 9 (Terraza Lounge Bar)", capacidad: 4, zona: "Terraza" },
  { id: "Mesa 11", nombre: "Mesa 11 (Zona VIP Exec)", capacidad: 8, zona: "VIP" },
  { id: "Mesa 12", nombre: "Mesa 12 (Zona VIP)", capacidad: 10, zona: "VIP" },
];

const HORARIOS = ["12:00", "13:00", "13:30", "14:30", "19:00", "20:00", "20:30", "21:30", "22:00"];

export default function App() {
  const [activeTab, setActiveTab] = useState('cliente');
  const [reservas, setReservas] = useState(() => {
    const saved = localStorage.getItem('gourmet_reservas');
    return saved ? JSON.parse(saved) : initialData;
  });

  const [selectedFechaFilter, setSelectedFechaFilter] = useState(new Date().toISOString().split('T')[0]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todas');

  const [formData, setFormData] = useState({
    nombreCliente: '',
    telefono: '',
    email: '',
    fecha: new Date().toISOString().split('T')[0],
    hora: '19:00',
    personas: '2',
    mesa: 'Mesa 3 (Interior - Principal)',
    zona: 'Interior',
    notas: ''
  });

  const [conflictWarning, setConflictWarning] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);
  const [occupancyRate, setOccupancyRate] = useState(0);

  useEffect(() => {
    localStorage.setItem('gourmet_reservas', JSON.stringify(reservas));
    calculateOccupancy();
  }, [reservas, selectedFechaFilter]);

  useEffect(() => {
    if (formData.fecha && formData.hora && formData.mesa) {
      const colision = reservas.find(r => 
        r.fecha === formData.fecha && 
        r.hora === formData.hora && 
        r.mesa === formData.mesa && 
        r.estado !== 'Cancelada'
      );

      if (colision) {
        setConflictWarning(`⚠️ Conflicto detectado: La ${formData.mesa} ya está reservada para el ${formData.fecha} a las ${formData.hora} por ${colision.nombreCliente}. Por favor elige otro horario o mesa.`);
      } else {
        setConflictWarning(null);
      }
    }
  }, [formData.fecha, formData.hora, formData.mesa, reservas]);

  const calculateOccupancy = () => {
    const totalSlots = MESAS_DISPONIBLES.length * HORARIOS.length;
    const reservasDia = reservas.filter(r => r.fecha === selectedFechaFilter && r.estado !== 'Cancelada').length;
    const rate = Math.round((reservasDia / totalSlots) * 100);
    setOccupancyRate(rate);
  };

  const showToast = (msg, type = 'success') => {
    setToastMessage({ msg, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmitReserva = (e) => {
    e.preventDefault();

    if (conflictWarning) {
      showToast("No se puede registrar. Existe un conflicto de duplicación de horario.", "error");
      return;
    }

    const nuevaReserva = {
      id: `RES-${Math.floor(100 + Math.random() * 900)}`,
      ...formData,
      personas: parseInt(formData.personas),
      estado: 'Confirmada',
      creadoEn: new Date().toISOString()
    };

    setReservas(prev => [nuevaReserva, ...prev]);
    showToast(`¡Reserva registrada con éxito! Código: ${nuevaReserva.id}`);

    setFormData(prev => ({
      ...prev,
      nombreCliente: '',
      telefono: '',
      email: '',
      notas: ''
    }));
  };

  const handleUpdateStatus = (id, newStatus) => {
    setReservas(prev => prev.map(r => r.id === id ? { ...r, estado: newStatus } : r));
    showToast(`Reserva ${id} actualizada a: ${newStatus}`);
  };

  const reservasFiltradas = reservas.filter(r => {
    const matchFecha = selectedFechaFilter ? r.fecha === selectedFechaFilter : true;
    const matchSearch = r.nombreCliente.toLowerCase().includes(searchTerm.toLowerCase()) || 
                        r.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        r.telefono.includes(searchTerm);
    const matchStatus = statusFilter === 'Todas' ? true : r.estado === statusFilter;
    return matchFecha && matchSearch && matchStatus;
  });

  return (
    <div className="app-wrapper">
      {/* Toast Banner */}
      {toastMessage && (
        <div className={`toast-container ${toastMessage.type === 'error' ? 'toast-error' : 'toast-success'}`}>
          <span>{toastMessage.type === 'error' ? '❌' : '✅'}</span>
          <p>{toastMessage.msg}</p>
        </div>
      )}

      {/* Header */}
      <header className="app-header">
        <div className="header-container">
          <div className="logo-group">
            <div className="logo-badge">🍽️</div>
            <div>
              <h1 className="logo-title">GourmetReserve</h1>
              <p className="logo-subtitle">Sistema Centralizado de Reservas v2.0</p>
            </div>
          </div>

          <nav className="nav-tabs">
            <button
              onClick={() => setActiveTab('cliente')}
              className={`tab-btn ${activeTab === 'cliente' ? 'active' : ''}`}
            >
              ✍️ Nueva Reserva (Cliente)
            </button>
            <button
              onClick={() => setActiveTab('admin')}
              className={`tab-btn ${activeTab === 'admin' ? 'active' : ''}`}
            >
              📋 Gestión (Admin)
            </button>
            <button
              onClick={() => setActiveTab('calendario')}
              className={`tab-btn ${activeTab === 'calendario' ? 'active' : ''}`}
            >
              📅 Calendario Interactivo
            </button>
            <button
              onClick={() => setActiveTab('mesas')}
              className={`tab-btn ${activeTab === 'mesas' ? 'active' : ''}`}
            >
              🗺️ Mapa de Mesas
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-container">
        {/* KPI Row */}
        <div className="kpi-grid">
          <div className="kpi-card">
            <p className="kpi-label">Reservas del Día</p>
            <div className="kpi-value-row">
              <span className="kpi-value">
                {reservas.filter(r => r.fecha === selectedFechaFilter && r.estado !== 'Cancelada').length}
              </span>
              <span className="kpi-tag">{selectedFechaFilter}</span>
            </div>
          </div>

          <div className="kpi-card">
            <p className="kpi-label">Ocupación Estimada</p>
            <div className="kpi-value-row">
              <span className="kpi-value" style={{ color: 'var(--success)' }}>{occupancyRate}%</span>
              <div className="progress-bar-bg">
                <div className="progress-bar-fill" style={{ width: `${occupancyRate}%` }}></div>
              </div>
            </div>
          </div>

          <div className="kpi-card">
            <p className="kpi-label">Total Histórico</p>
            <div className="kpi-value-row">
              <span className="kpi-value" style={{ color: '#818cf8' }}>{reservas.length}</span>
              <span style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>Registradas</span>
            </div>
          </div>

          <div className="kpi-card">
            <p className="kpi-label">Prevención de Conflictos</p>
            <div className="kpi-value-row">
              <span className="kpi-value" style={{ color: 'var(--accent-gold)' }}>100%</span>
              <span style={{ fontSize: '12px', color: 'var(--success)', fontWeight: '700' }}>Activo (Real-Time)</span>
            </div>
          </div>
        </div>

        {/* TAB 1: FORMULARIO CLIENTE */}
        {activeTab === 'cliente' && (
          <div className="customer-layout">
            <div className="dashboard-card">
              <div className="card-header-line">
                <h2 className="card-title-text">📅 Registrar Nueva Reserva</h2>
                <p className="card-subtitle-text">
                  Complete los datos del cliente. El sistema verifica la disponibilidad de mesas y horarios en tiempo real para evitar duplicaciones.
                </p>
              </div>

              {conflictWarning && (
                <div className="conflict-box">
                  <span style={{ fontSize: '20px' }}>⚠️</span>
                  <div>
                    <div className="conflict-title">Conflicto de Horario Detectado</div>
                    <div>{conflictWarning}</div>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmitReserva}>
                <div className="form-grid-2">
                  <div className="form-field">
                    <label className="form-label">Nombre Completo *</label>
                    <input
                      type="text"
                      name="nombreCliente"
                      required
                      placeholder="Ej. Gerson Soriano"
                      value={formData.nombreCliente}
                      onChange={handleInputChange}
                      className="form-input"
                    />
                  </div>

                  <div className="form-field">
                    <label className="form-label">Teléfono / WhatsApp *</label>
                    <input
                      type="tel"
                      name="telefono"
                      required
                      placeholder="Ej. 987654321"
                      value={formData.telefono}
                      onChange={handleInputChange}
                      className="form-input"
                    />
                  </div>
                </div>

                <div className="form-grid-3">
                  <div className="form-field">
                    <label className="form-label">Fecha *</label>
                    <input
                      type="date"
                      name="fecha"
                      required
                      value={formData.fecha}
                      onChange={handleInputChange}
                      className="form-input"
                    />
                  </div>

                  <div className="form-field">
                    <label className="form-label">Hora *</label>
                    <select
                      name="hora"
                      value={formData.hora}
                      onChange={handleInputChange}
                      className="form-select"
                    >
                      {HORARIOS.map(h => (
                        <option key={h} value={h}>{h} hrs</option>
                      ))}
                    </select>
                  </div>

                  <div className="form-field">
                    <label className="form-label">Personas *</label>
                    <select
                      name="personas"
                      value={formData.personas}
                      onChange={handleInputChange}
                      className="form-select"
                    >
                      {[1, 2, 3, 4, 5, 6, 8, 10, 12].map(n => (
                        <option key={n} value={n}>{n} Persona{n > 1 ? 's' : ''}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="form-field">
                  <label className="form-label">Selección de Mesa *</label>
                  <select
                    name="mesa"
                    value={formData.mesa}
                    onChange={handleInputChange}
                    className="form-select"
                  >
                    {MESAS_DISPONIBLES.map(m => (
                      <option key={m.id} value={m.nombre}>
                        {m.nombre} - Capacidad: {m.capacidad}p ({m.zona})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-field">
                  <label className="form-label">Notas Especiales / Ocasión</label>
                  <textarea
                    name="notas"
                    rows="3"
                    placeholder="Ej. Cumpleaños, requerimiento de silla alta..."
                    value={formData.notas}
                    onChange={handleInputChange}
                    className="form-textarea"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  disabled={!!conflictWarning}
                  className="btn-submit"
                >
                  {conflictWarning ? '🚫 Solucione el conflicto antes de confirmar' : '✅ Confirmar y Registrar Reserva'}
                </button>
              </form>
            </div>

            {/* Sidebar Preview */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div className="dashboard-card">
                <h3 className="card-title-text" style={{ fontSize: '16px', marginBottom: '15px' }}>
                  👁️ Resumen en Tiempo Real
                </h3>
                <div className="preview-box">
                  <div className="preview-row">
                    <span className="preview-label">Cliente:</span>
                    <span className="preview-value">{formData.nombreCliente || '---'}</span>
                  </div>
                  <div className="preview-row">
                    <span className="preview-label">Fecha y Hora:</span>
                    <span className="preview-value" style={{ color: 'var(--accent-gold)' }}>{formData.fecha} a las {formData.hora} hs</span>
                  </div>
                  <div className="preview-row">
                    <span className="preview-label">Mesa:</span>
                    <span className="preview-value">{formData.mesa}</span>
                  </div>
                  <div className="preview-row">
                    <span className="preview-label">Estado Validación:</span>
                    <span className="preview-value" style={{ color: conflictWarning ? 'var(--danger)' : 'var(--success)' }}>
                      {conflictWarning ? '❌ Conflicto' : '✅ Disponible'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="dashboard-card">
                <h4 style={{ color: 'var(--accent-gold)', fontSize: '13px', textTransform: 'uppercase', marginBottom: '8px' }}>
                  💡 Política de Reservas
                </h4>
                <p style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                  Las reservas se mantienen guardadas de manera centralizada. Tolerancia máxima de 15 minutos en horas de alta demanda.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: GESTION ADMIN */}
        {activeTab === 'admin' && (
          <div className="dashboard-card">
            <div className="card-header-line" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '15px' }}>
              <div>
                <h2 className="card-title-text">📋 Panel de Administración de Reservas</h2>
                <p className="card-subtitle-text">Gestión centralizada de ocupación, búsqueda y cambio de estados.</p>
              </div>

              <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                <input
                  type="date"
                  value={selectedFechaFilter}
                  onChange={(e) => setSelectedFechaFilter(e.target.value)}
                  className="form-input"
                  style={{ width: 'auto', padding: '8px 12px', fontSize: '12px' }}
                />
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="form-select"
                  style={{ width: 'auto', padding: '8px 12px', fontSize: '12px' }}
                >
                  <option value="Todas">Todos los Estados</option>
                  <option value="Confirmada">Confirmada</option>
                  <option value="Completada">Completada</option>
                  <option value="Cancelada">Cancelada</option>
                </select>
                <input
                  type="text"
                  placeholder="🔍 Buscar cliente..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="form-input"
                  style={{ width: '180px', padding: '8px 12px', fontSize: '12px' }}
                />
              </div>
            </div>

            <div className="table-wrapper">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Cliente</th>
                    <th>Contacto</th>
                    <th>Fecha / Hora</th>
                    <th>Mesa / Personas</th>
                    <th>Estado</th>
                    <th style={{ textAlign: 'right' }}>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {reservasFiltradas.length === 0 ? (
                    <tr>
                      <td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: 'var(--text-muted)' }}>
                        No se encontraron reservas que coincidan con los filtros aplicados.
                      </td>
                    </tr>
                  ) : (
                    reservasFiltradas.map((r) => (
                      <tr key={r.id}>
                        <td style={{ color: 'var(--accent-gold)', fontWeight: '700', fontFamily: 'monospace' }}>{r.id}</td>
                        <td>
                          <strong>{r.nombreCliente}</strong>
                          {r.notas && <div style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>"{r.notas}"</div>}
                        </td>
                        <td>{r.telefono}</td>
                        <td>
                          <div>{r.fecha}</div>
                          <div style={{ color: 'var(--accent-gold)', fontSize: '11px' }}>{r.hora} hrs</div>
                        </td>
                        <td>
                          <div>{r.mesa}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{r.personas} Personas</div>
                        </td>
                        <td>
                          <span className={`badge badge-${r.estado.toLowerCase()}`}>
                            {r.estado}
                          </span>
                        </td>
                        <td style={{ textAlign: 'right' }}>
                          {r.estado === 'Confirmada' && (
                            <button
                              onClick={() => handleUpdateStatus(r.id, 'Completada')}
                              className="btn-action btn-complete"
                            >
                              Completar
                            </button>
                          )}
                          {r.estado !== 'Cancelada' && (
                            <button
                              onClick={() => handleUpdateStatus(r.id, 'Cancelada')}
                              className="btn-action btn-cancel"
                            >
                              Cancelar
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: CALENDARIO INTERACTIVO */}
        {activeTab === 'calendario' && (
          <div className="dashboard-card">
            <div className="card-header-line" style={{ display: 'flex', justifyBetween: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '15px' }}>
              <div>
                <h2 className="card-title-text">📅 Calendario Interactivo de Ocupación</h2>
                <p className="card-subtitle-text">Visualización por turnos horarios para la fecha seleccionada.</p>
              </div>
              <input
                type="date"
                value={selectedFechaFilter}
                onChange={(e) => setSelectedFechaFilter(e.target.value)}
                className="form-input"
                style={{ width: 'auto', padding: '8px 12px', color: 'var(--accent-gold)', fontWeight: 'bold' }}
              />
            </div>

            <div className="calendar-grid">
              {HORARIOS.map((hora) => {
                const reservasTurno = reservas.filter(r => r.fecha === selectedFechaFilter && r.hora === hora && r.estado !== 'Cancelada');
                const estaLleno = reservasTurno.length >= MESAS_DISPONIBLES.length;

                return (
                  <div key={hora} className="time-slot-card" style={{ borderColor: estaLleno ? 'var(--danger)' : reservasTurno.length > 0 ? 'var(--accent-gold)' : 'var(--border-color)' }}>
                    <div className="slot-header">
                      <span className="slot-time">⏰ {hora} hrs</span>
                      <span className="badge" style={{ background: estaLleno ? 'var(--danger-bg)' : 'var(--success-bg)', color: estaLleno ? 'var(--danger)' : 'var(--success)' }}>
                        {reservasTurno.length} / {MESAS_DISPONIBLES.length} Mesas
                      </span>
                    </div>

                    {reservasTurno.length === 0 ? (
                      <p style={{ fontSize: '12px', color: 'var(--text-muted)', fontStyle: 'italic', padding: '10px 0' }}>Disponible para reservas.</p>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        {reservasTurno.map(res => (
                          <div key={res.id} style={{ background: 'var(--bg-card)', padding: '10px', borderRadius: '8px', fontSize: '12px', border: '1px solid var(--border-color)' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold' }}>
                              <span>{res.nombreCliente}</span>
                              <span style={{ color: 'var(--accent-gold)' }}>{res.mesa.split(' ')[0]} {res.mesa.split(' ')[1]}</span>
                            </div>
                            <div style={{ fontSize: '11px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                              👥 {res.personas} pers | 📞 {res.telefono}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 4: MAPA DE MESAS */}
        {activeTab === 'mesas' && (
          <div className="dashboard-card">
            <div className="card-header-line">
              <h2 className="card-title-text">🗺️ Distribución y Mapa de Mesas</h2>
              <p className="card-subtitle-text">Estado en tiempo real por zonas del restaurante (Interior, Terraza, VIP).</p>
            </div>

            <div className="zone-grid">
              {['Interior', 'Terraza', 'VIP'].map(zona => (
                <div key={zona} className="zone-box">
                  <h3 className="zone-title">🏛️ Zona {zona}</h3>
                  <div>
                    {MESAS_DISPONIBLES.filter(m => m.zona === zona).map(mesa => {
                      const ocupada = reservas.some(r => r.fecha === selectedFechaFilter && r.mesa === mesa.nombre && r.estado !== 'Cancelada');
                      return (
                        <div key={mesa.id} className={`table-item ${ocupada ? 'occupied' : ''}`}>
                          <div>
                            <div style={{ fontWeight: '700', fontSize: '13px' }}>{mesa.nombre}</div>
                            <div style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>Capacidad: {mesa.capacidad} personas</div>
                          </div>
                          <span className={`badge ${ocupada ? 'badge-cancelada' : 'badge-confirmada'}`}>
                            {ocupada ? 'Ocupada' : 'Libre'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      <footer className="footer-text">
        <p>GourmetReserve App - Proyecto Académico IDAT | Desarrollo de Interfaces 2</p>
      </footer>
    </div>
  );
}
